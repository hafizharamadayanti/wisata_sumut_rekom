// Toggle class active
const navbarNav =  document.querySelector('.navbar-nav');

//ketika wisata-menu diklik
document.querySelector('#wisata-menu').onclick = () => {
    navbarNav.classList.toggle('active');
};

//klik diluar side bar untuk menghilangkan nav
const wisata = document.querySelector('#wisata-menu');

document.addEventListener('click', function(e){
    if (!wisata.contains(e.target) && !navbarNav.contains(e.target)){
        navbarNav.classList.remove('active');
    }
});